const express = require("express");
const multer = require("multer");
const path = require("path");
const jwt = require("jsonwebtoken");
// const bcrypt = require("bcryptjs");
const nodemailer = require("nodemailer");
const Login = require("../models/Login");
const router = express.Router();
require("dotenv").config();

module.exports = router;